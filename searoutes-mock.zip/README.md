# Searoutes-Shaped Schedules Mock + Viewer

Run the mock API + open the viewer at http://127.0.0.1:4010/ui/viewer.html

```bash
pip install -r requirements.txt
uvicorn mock_server:app --port 4010 --reload
```
